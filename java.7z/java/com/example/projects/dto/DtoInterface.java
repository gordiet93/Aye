package com.example.projects.dto;

public interface DtoInterface {
}
