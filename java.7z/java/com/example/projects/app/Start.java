package com.example.projects.app;

public class Start {

    public static void main(String[] args) {
        App app = new App();
    }
}
