package com.example.projects.rest;

import com.example.projects.service.TestService;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import java.util.concurrent.CompletableFuture;

public class Resource {

    @Inject
    private TestService testService;

    @GET
    public void asyncGet(@Suspended final AsyncResponse asyncResponse) {
        CompletableFuture
                .runAsync(() -> testService.test())
                .thenApply((result) -> asyncResponse.resume(result));
    }
}
