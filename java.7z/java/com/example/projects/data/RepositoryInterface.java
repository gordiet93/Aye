package com.example.projects.data;

public interface RepositoryInterface {


}
