package com.example.projects.util;

        import javax.enterprise.context.RequestScoped;
        import javax.enterprise.inject.Produces;
        import javax.enterprise.inject.spi.InjectionPoint;
        import javax.faces.context.FacesContext;
        import javax.persistence.EntityManager;
        import javax.persistence.PersistenceContext;
        import java.util.logging.Logger;

/**
 * Created by GTaggart on 28/02/2018.
 */
public class Resources {

    @Produces
    @PersistenceContext
    private EntityManager em;

    @Produces
    public Logger produceLog(InjectionPoint injectionPoint) {
        return Logger.getLogger(injectionPoint.getMember().getDeclaringClass().getName());
    }
}
