import React, { Component } from 'react';
import Header from './components/Header';
import MainPage from './components/mainPage'
import { BrowserRouter, Route } from 'react-router-dom';

class App extends Component {
    render() {
        return(
            <div>
                <Header />
                <MainPage />
            </div>
        );
    }
}

/*  Part of the bike App with the fetch calls
class AutoSearch extends Component {
    constructor(props) {
        super(props)

        this.state = {
            bikes: [],
            stations: [],
            bikeId: '',
            startId: '',
            endId: '',
            duration: ''
        }

        this.handleNewRequest = this.handleNewRequest.bind(this)
        this.handleNewRequest2 = this.handleNewRequest2.bind(this)
    }

    handleNewRequest = (value) => {
        this.setState ({
            startId: value.stationId
        });
    }

    handleNewRequest2 = (value) => {
        this.setState ({
            endId: value.stationId
        });
    }

    handleChange = (event, index, value) => this.setState({bikeId: value});

    handleChangeDuration = (event) => {
        this.setState({
            duration: event.target.value,
        });
    };

    buttonClick = (event) => {
    fetch('http://localhost:8080/BikeWebapp-1/rest/journey/add', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            journeyId: '',
            bikeId: this.state.bikeId,
            startStationId: this.state.startId,
            endStationId: this.state.endId,
            duration: this.state.duration,
        })
    })

    }

    componentDidMount() {
        fetch('http://localhost:8080/BikeWebapp-1/rest/station/all')
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        stations: result
                    });
                }
            );
        fetch('http://localhost:8080/BikeWebapp-1/rest/bike/all')
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        bikes: result
                    });
                }
            );
    }

    render() {
        return (
            <MuiThemeProvider>
                <div>
                    <SelectField
                    value={this.state.bikeId}
                    onChange={this.handleChange}>
                        {this.state.bikes.map(item =>
                        <MenuItem key={item.bikeId} value={item.bikeId} primaryText={item.bikeId}/>)}
                    </SelectField>
                    <AutoComplete
                        hintText={'Start Station'}
                        dataSource={this.state.stations}
                        filter={AutoComplete.fuzzyFilter}
                        dataSourceConfig={{text: "stationName", value: "stationId"}}
                        fullWidth={true}
                        onNewRequest={this.handleNewRequest}
                    />
                    <AutoComplete
                        hintText={'End Station'}
                        dataSource={this.state.stations}
                        filter={AutoComplete.fuzzyFilter}
                        dataSourceConfig={{text: "stationName", value: "stationId"}}
                        fullWidth={true}
                        onNewRequest={this.handleNewRequest2}
                    />
                    <TextField
                    id="duration"
                    hintText="Enter journey duration in mins"
                    onChange={this.handleChangeDuration}
                    /><br />
                    <RaisedButton label="Add" onClick={this.buttonClick}/>
                </div>
            </MuiThemeProvider>
        )
    }
}

class BikeSearch extends Component {
    constructor(props) {
        super(props)

        this.state = {
            bike: {
                bikeId: '',
                journeyIds: [],
                currentStation: '',
                previousStation: ''
            }
        }
        this.handleKeyPress = this.handleKeyPress.bind(this)
    }

    handleKeyPress = (event) => {
        if (event.key === 'Enter') {
            fetch('http://localhost:8080/BikeWebapp-1/rest/bike/query?bikeid=' + event.target.value)
                .then(res => res.json())
                .then(data => this.setState({
                    bike: data
                }))
        }
    }

    render() {
        return (
            <div>
                Change Bike:
                <input
                    type="text"
                    onKeyPress={this.handleKeyPress}
                /> <br />
                Bike Details <br />
                {this.state.bike.bikeId} {this.state.bike.journeyIds}
            </div>
        );
    }
}

class DatePick extends Component {
    constructor(props) {
        super(props)

        this.state = {
            date: null,
        };

        this.handleChangeDate = this.handleChangeDate.bind(this);
    }

    handleChangeDate = (event, date) => {
        this.setState ({
            date: date
        });
    }

    render() {
        return (
            <MuiThemeProvider>
                <div>
                    <DatePicker hintText={this.props.hint} container="inline" value={this.state.date} onChange={(this.handleChangeDate)} />
                </div>
            </MuiThemeProvider>
        )
    }
}

class Search extends Component {
    constructor(props) {
        super(props)

        this.state = {
            journeys: []
        };
    }


    onclick() {
        fetch('http://localhost:8080/BikeWebapp-1/rest/journeys')
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        journeys: result
                    });
                }
            );
    }

    render() {
        return (
            <div>
                <DatePick hint="Start Date"/>
                <DatePick hint="End Date"/>
                <Button onclick/>
            </div>
        )
    }
}

class Button extends Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <MuiThemeProvider>
                <div>
                    <RaisedButton label="Add"/>
                </div>
            </MuiThemeProvider>
        )
    }
}

class JourneyTable extends Component {
    constructor(props) {
        super(props)

        this.state = {
            showCheckboxes: false,
            journeys: []
        };
    }

    componentDidMount() {
        fetch('http://localhost:8080/BikeWebapp-1/rest/journey/all')
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        journeys: result
                    });
                }
            );
    }

    render() {
        const {journeys} = this.state;
        return (
            <MuiThemeProvider>
            <Table>
                <TableHeader
                    displaySelectAll={this.state.showCheckboxes}
                >
                    <TableRow>
                        <TableHeaderColumn>Journey ID</TableHeaderColumn>
                        <TableHeaderColumn>Bike</TableHeaderColumn>
                        <TableHeaderColumn>Start Station</TableHeaderColumn>
                        <TableHeaderColumn>End Station</TableHeaderColumn>
                        <TableHeaderColumn>Duration in mins</TableHeaderColumn>
                        <TableHeaderColumn>Departed Outside Top 5</TableHeaderColumn>
                    </TableRow>
                </TableHeader>
                <TableBody
                    displayRowCheckbox={this.state.showCheckboxes}
                >
                    {journeys.map(journey =>(
                        <TableRow>
                            <TableRowColumn>{journey.journeyId}</TableRowColumn>
                            <TableRowColumn>{journey.bikeId}</TableRowColumn>
                            <TableRowColumn>{journey.startStationName}</TableRowColumn>
                            <TableRowColumn>{journey.endStationName}</TableRowColumn>
                            <TableRowColumn>{journey.duration}</TableRowColumn>
                            <TableRowColumn>{journey.outsideTopFive}</TableRowColumn>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
            </MuiThemeProvider>
        )
    }
}*/

export default App;
