import React, { Component } from 'react';
import JourneySearch from './JourneySearch';

export default class MainPage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      searchCriteria: [],
      bikes: [],
      result: [],
    };
  }

  componentDidMount() {
    this.getBikes();
  }

  getBikes() {
    fetch('http://localhost:8080/BikeWebapp-1/rest/bike/all', {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then((response) => {
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          return response.json();
        }
        throw new TypeError('Could not get bikes');
      })
      .then((response) => {
        this.bikes(response);
      })
      .catch((error) => {
        console.log('Could not get bikestttt');
      });
  }

  render() {
    return (
      <div>
        <JourneySearch />
      </div>
    );
  }
}