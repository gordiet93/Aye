import React from 'react';
import { FormGroup, Label, Input, Col, Row, Button } from 'reactstrap';

export default function DateSearch(props) {
  return(
    <Row form>
      <Col>
        <FormGroup>
          <Label for="startDate">Start Date:</Label>
          <Input type="date" name="startDate" id="startDate" title="Start Date" onChange={props.startDateOnChange} />
        </FormGroup>
      </Col>
      <Col>
        <FormGroup>
          <Label for="endDate">End Date:</Label>
          <Input type="date" name="endDate" id="endDate" title="End Date" onChange={props.endDateOnChange} />
        </FormGroup>
      </Col>
    </Row>
  );
}