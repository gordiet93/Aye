import React, { Component } from 'react';
import { Card, Button, CardHeader, CardFooter, CardBody,
  CardTitle, CardText, Row, Col, Form, FormGroup }  from 'reactstrap';
import DateSearch from './DateSearch';
import JourneyDurationSearch from './JourneyDurationSearch';

export default class JourneySearch extends Component {
  constructor(props) {
    super(props);

    this.state = {
      
    }
  }

  render() {
    return(
      <div>
        <Row>
          <Col xs="3">
            <Card>
              <CardHeader>Journey Search</CardHeader>
              <CardBody>
                <Form>
                  <DateSearch />
                  <JourneyDurationSearch />
                  <Button>Search</Button>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
        <Card>
          <CardHeader>Journey Search</CardHeader>
          <CardBody>
            <Form>
              <DateSearch />
              <JourneyDurationSearch />
              <Button>Search</Button>
            </Form>
          </CardBody>
        </Card>
      </div>
    );
  }
}
