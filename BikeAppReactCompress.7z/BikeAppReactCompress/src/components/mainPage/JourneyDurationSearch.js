import React, { Component } from 'react';
import { FormGroup, Label, Input, Col, Row } from 'reactstrap';

export default class JourneyDurationSearch extends Component {
  constructor(props){
    super(props);

    this.state = {
      value: 'longerThan',
    }
  }

  renderSearchType(value) {
    switch(value) {
      case 'longerThan':
        return(
          <FormGroup>
            <Label for="longerThanNum">Duration in mintues</Label>
            <Input type="number" name="longerThanNum" id="longerThanNum" title="Longer Than Value" />
          </FormGroup>
        );
      case 'shorterThan':
        return(
          <FormGroup>
            <Label for="shorterThanNum">Duration in mintues</Label>
            <Input type="number" name="shorterThanNum" id="shorterThanNum" title="Shorter Than Value" />
          </FormGroup>
        );
      case 'between':
        return(
          <Row>
            <Col>
              <FormGroup>
                <Label for="durationFrom">Start Value</Label>
                <Input type="number" name="number" id="numberShorterThan" title="Start Value" />
              </FormGroup>
            </Col>
            <Col>
              <FormGroup>
                <Label for="durationToo">End Value</Label>
                <Input type="number" name="number" id="numberShorterThan" title="End Value" />
              </FormGroup>
            </Col>
          </Row>
        );
      default:
        return <p>Incorrect Search Type</p>
    }
  }

  changeSearchType = (e) => {
    this.setState({
      value: e.target.value,
    });
  }

  render() {
    return(
      <Row form>
        <Col>
          <FormGroup>
            <Label for="durationSearchSelect">Search Type:</Label>
            <Input type="select" name="durationSearchSelect" id="durationSearchSelect" onChange={this.changeSearchType}>
              <option value="longerThan">Longer Than</option>
              <option value="shorterThan">Shorter Than</option>
              <option value="between">Between</option>
            </Input>
          </FormGroup>
        </Col>
        <Col>
          {this.renderSearchType(this.state.value)}
        </Col>
      </Row>
    );
  }
}
