package Entities;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by GTaggart on 19/02/2018.
 */
public class StationTest {
    @Test
    public void checkArrivals() {

    }

    @Test
    public void checkDepartures() {

    }
}