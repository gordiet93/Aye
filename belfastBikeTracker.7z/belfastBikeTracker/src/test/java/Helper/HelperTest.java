package Helper;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.*;

/**
 * Created by GTaggart on 19/02/2018.
 */
public class HelperTest {

    Helper helper;

    @Before
    public void setUp() {
        helper = new Helper();
    }

    @Test
    public void getData() {

    }

    @Test
    public void calculateTime() {

    }

    @Test
    public void convertToDate() {

    }

    @Test
    public void getBikeIDs() {
        //assertEquals(Arrays.asList(1,2,3));
    }
}