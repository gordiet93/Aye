package DatabaseAccess;

import Entities.Bike;
import Entities.Station;

import java.sql.*;

/**
 * Created by GTaggart on 18/01/2018.
 */
public class MySQLAccess {

    private static Connection connection;

    static {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:2018/bikes?" +
                    "user=gordiet&password=17Winter");
            System.out.println("Connected to the database");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /*public void getConnection() throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection("jdbc:mysql://localhost:2018/bikes?" +
                "user=gordiet&password=17Winter");

        System.out.println("Connected to the database");
    }*/

    public static void insertBike(Bike bike) {

        PreparedStatement preparedStatement = null;
        String query = "INSERT INTO bike"
                + "(id, currentStation, previousStation) VALUES"
                + "(?,?,?)";

        try {
            preparedStatement = connection.prepareStatement(query);

            preparedStatement.setInt(1, bike.getId());
            preparedStatement.setString(2, bike.getCurrentStation());
            preparedStatement.setString(3, bike.getPreviousStation());

            preparedStatement.executeUpdate();

            System.out.println("Record is inserted into bike table");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void insertStation(Station station) {

        PreparedStatement preparedStatement = null;
        String query = "INSERT INTO station"
                + "(name) VALUES"
                + "(?)";

        try {
            preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, station.getStationName());

            preparedStatement.executeUpdate();

            System.out.println("Record is inserted into station table");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void insertJourney(Bike bike) {
        PreparedStatement preparedStatement = null;
        String query = "INSERT INTO journey"
                + "(departureStation, destinationStation, bike) VALUES"
                + "(?,?,?)";

        try {
            preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, bike.getPreviousStation());
            preparedStatement.setString(2, bike.getCurrentStation());
            preparedStatement.setInt(3, bike.getId());

            preparedStatement.executeUpdate();//check if just execute

            System.out.println("Record is inserted into journey table");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void updateStation(Station station) {
        PreparedStatement preparedStatement = null;
        String query = "UPDATE station SET totalArrivals = ?, totalDepartures = ? WHERE id = ?";

        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(3, station.getStationName());

            preparedStatement.executeUpdate();

            System.out.println("Station record is updated");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void updateBike(Bike bike) {
        PreparedStatement preparedStatement = null;
        String query = "UPDATE bike SET currentStation = ?, previousStation = ? WHERE id = ?";

        try {
            preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, bike.getCurrentStation());
            preparedStatement.setString(2, bike.getPreviousStation());
            preparedStatement.setInt(3, bike.getId());

            preparedStatement.executeUpdate();

            System.out.println("Bike record is updated");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void loadStation(Station station) {
        PreparedStatement preparedStatement = null;
        String query = "SELECT * FROM station WHERE name = ?";

        try {
            preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, station.getStationName());

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.first()) {

            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void loadBike(Bike bike) {
        PreparedStatement preparedStatement = null;
        String query = "SELECT * FROM bike WHERE id = ?";

        try {
            preparedStatement = connection.prepareStatement(query);

            preparedStatement.setInt(1, bike.getId());

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.first()) {

            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

}
