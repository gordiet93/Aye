package App;

import Entities.City;
import Entities.Station;
import Helper.Helper;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    private static final long REFRESH_TIME = 1683;

    public static void main(String[] args) {

        try {
            City city = Helper.getData();
            List<Station> stations = city.getStations();

            while (true) {
                List<Station> updatedStations = Helper.getData().getStations();

                for (int i = 0; i < stations.size(); i++) {
                    ArrayList<Integer> updatedBikeIDs = Helper.getBikeIDs(updatedStations.get(i).getBikes());

                    stations.get(i).checkArrivals(updatedBikeIDs);
                    stations.get(i).checkDepartures(updatedBikeIDs);
                }
                System.out.println("Bikes in transit : " + Station.getBikesInTransit().size());
                //Thread.sleep(REFRESH_TIME);
            }
        } catch (IOException | JAXBException e) {
            e.printStackTrace();
        }
    }
}
