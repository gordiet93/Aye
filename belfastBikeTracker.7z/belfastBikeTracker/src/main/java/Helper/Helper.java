package Helper;

import Entities.Bike;
import Entities.City;
import Entities.Station;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Helper {

    public static City getData() throws IOException, JAXBException {
        File file = new File("src/bikes.xml");
        JAXBContext jaxbContext = JAXBContext.newInstance(City.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        return (City) unmarshaller.unmarshal(file);
    }

    public static String calculateTime(long time) {
        long seconds = time / 1000 % 60;
        long minutes = time / (60 * 1000) % 60;
        long hours = time / (60 * 60 * 1000) % 24;
        long days = time / (24 * 60 * 60 * 1000);

        String wordTime;

        if (days > 0) {
            wordTime = days + " Days, " + hours + " Hours, " + minutes + " Minutes, " + seconds + " Seconds";
        } else if (hours > 0) {
            wordTime = hours + " Hours, " + minutes + " Minutes, " + seconds + " Seconds";
        } else if (minutes > 0) {
            wordTime = minutes + " Minutes, " + seconds + " Seconds";
        } else {
            wordTime = seconds + " Seconds";
        }
        return wordTime;
    }

    public static String convertToDate(long time) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
        Date date = new Date(time);
        return sdf.format(date);
    }

    public static ArrayList<Integer> getBikeIDs(List<Bike> bikes) {
        ArrayList<Integer> bikeIDs = new ArrayList<>();
        for (Bike bike: bikes) {
            bikeIDs.add(bike.getId());
        }
        return bikeIDs;
    }


//    public static String getCurrentWeatherConditions() throws Exception {
//        Document doc = parseXML("src/belfast.xml");
//        XPathFactory xPathFactory = XPathFactory.newInstance();
//        XPath xPath = xPathFactory.newXPath();
//        XPathExpression expr = xPath.compile("//current/temperature[@value]");
//
//        NodeList nl = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
//        Node currentItem = nl.item(0);
//
//        String temp = currentItem.getAttributes().getNamedItem("value").getNodeValue();
//
//        return "The current temperature is: " + temp + " Celsius";
//    }
}
