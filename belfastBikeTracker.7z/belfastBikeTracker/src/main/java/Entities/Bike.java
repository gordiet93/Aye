package Entities;

import javax.xml.bind.annotation.XmlAttribute;

public class Bike {

    private int id;
    private String previousStation;
    private String currentStation;
    private long departureTime;
    private boolean departedOutsideTopFive;

    public Bike(){
        departedOutsideTopFive = false;
        previousStation = "N/A";
    }

    public Bike(int id, String stationName) {
        this.id = id;
        this.currentStation = stationName;
    }

    public Bike(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    @XmlAttribute(name = "number")
    public void setId(int id) {
        this.id = id;
    }

    public String getPreviousStation() {
        return previousStation;
    }


    public void setPreviousStation(String previousStation) {
        this.previousStation = previousStation;
    }

    public String getCurrentStation() {
        return currentStation;
    }

    @XmlAttribute(name = "name")
    public void setCurrentStation(String currentStation) {
        this.currentStation = currentStation;
    }

    public long getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(long departureTime) {
        this.departureTime = departureTime;
    }

    public boolean isDepartedOutsideTopFive() {
        return departedOutsideTopFive;
    }

    public void setDepartedOutsideTopFive(boolean departedOutsideTopFive) {
        this.departedOutsideTopFive = departedOutsideTopFive;
    }
}
