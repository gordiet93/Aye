package Entities;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by GTaggart on 26/01/2018.
 */
@XmlRootElement(name = "city")
public class City {

    private List<Station> stations;
    private String name;

    public String getName() {
        return name;
    }

    @XmlAttribute
    public void setName(String name) {
        this.name = name;
    }

    public List<Station> getStations() {
        return stations;
    }

    @XmlElement(name = "place")
    public void setStations(List<Station> stations) {
        this.stations = stations;
    }
}