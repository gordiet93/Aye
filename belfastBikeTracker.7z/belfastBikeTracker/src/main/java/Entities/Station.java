package Entities;

import Helper.Helper;

import javax.xml.bind.annotation.*;
import java.util.*;
import static Helper.Helper.calculateTime;
import static Helper.Helper.convertToDate;

public class Station {

    private static List<Bike> bikesInTransit = new ArrayList<>();
    private String stationName;
    private List<Bike> bikes;

    private static final long MIN_JOURNEY_TIME = 600000;

    public Station() {
        this.bikes = new ArrayList<Bike>() {};
    }

    public void checkArrivals(ArrayList<Integer> updatedBikeIds) {
        for (Iterator<Bike> iterator = bikesInTransit.iterator(); iterator.hasNext(); ) {
            Bike transitBike = iterator.next();

            if (updatedBikeIds.contains(transitBike.getId())) {
                long journeyTime = System.currentTimeMillis() - transitBike.getDepartureTime();

                System.out.println("Bike : " + transitBike.getId() + " arrived at : " + stationName + " from "
                        + transitBike.getPreviousStation() + " at " + convertToDate(System.currentTimeMillis())
                        + System.lineSeparator() + "Total journey time : "
                        + calculateTime(journeyTime));

                if ((transitBike.getPreviousStation().equals(stationName)) && (journeyTime < MIN_JOURNEY_TIME)) {
                    System.out.println("Journey time too short to record");
                } else if ((transitBike.getPreviousStation().equals(stationName)) && (journeyTime > MIN_JOURNEY_TIME)) {
                        System.out.println("Bike may have re-entered the top five, recording journey anyway");
                }

                transitBike.setCurrentStation(stationName);
                bikes.add(transitBike);
                iterator.remove();
            }
        }

        //check for new bikes
        ArrayList<Integer> bikeIDs = Helper.getBikeIDs(bikes);
        for (Integer updatedBikeId : updatedBikeIds) {
            if (!bikeIDs.contains(updatedBikeId)) {
                Bike bike = new Bike(updatedBikeId, stationName);
                bikes.add(bike);
                System.out.println("Created new bike : " + updatedBikeId + " at station : " + stationName + " at "
                        + convertToDate(System.currentTimeMillis()));
            }
        }
    }

    public void checkDepartures(ArrayList<Integer> updatedBikeIds) {

        for (Iterator<Bike> iterator = bikes.iterator(); iterator.hasNext(); ) {
            Bike bike = iterator.next();

            if (!updatedBikeIds.contains(bike.getId())) {

                System.out.println("Bike : " + bike.getId() + " departed : " + stationName + " at "
                        + convertToDate(System.currentTimeMillis()));

                if (bikes.size() > 5) {
                    System.out.println("Note: bike may still be at station but out of top 5");
                    bike.setDepartedOutsideTopFive(true);
                }

                bike.setPreviousStation(stationName);
                bike.setCurrentStation("In Transit");
                bike.setDepartureTime(System.currentTimeMillis());
                bikesInTransit.add(bike);
                iterator.remove();
            }
        }
    }

    public String getStationName() {
        return stationName;
    }

    @XmlAttribute(name = "name")
    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public List<Bike> getBikes() {
        return bikes;
    }

    @XmlElement(name = "bike")
    public void setBikes(List<Bike> bikes) {
        this.bikes = bikes;
    }

    public static List<Bike> getBikesInTransit() {
        return bikesInTransit;
    }

    public static void setBikesInTransit(List<Bike> bikesInTransit) {
        Station.bikesInTransit = bikesInTransit;
    }
}
